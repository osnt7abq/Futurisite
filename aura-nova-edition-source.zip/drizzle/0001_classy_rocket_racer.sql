CREATE TABLE `activeMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`lastSeen` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activeMembers_id` PRIMARY KEY(`id`),
	CONSTRAINT `activeMembers_sessionId_unique` UNIQUE(`sessionId`)
);
