import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { trackActiveSession, getActiveCount } from "./db";
import { nanoid } from "nanoid";
import Stripe from "stripe";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2026-02-25.clover',
});

// Placeholder price IDs - in production, these would be your actual Stripe price IDs
const STRIPE_PRICES: Record<string, string> = {
  starter: 'price_1QkYXVSRjVdAcQer6000',
  pro: 'price_1QkYXVSRjVdAcQer6001',
  enterprise: 'price_1QkYXVSRjVdAcQer6002',
};

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  community: router({
    trackSession: publicProcedure.mutation(async () => {
      const sessionId = nanoid();
      await trackActiveSession(sessionId);
      return { sessionId };
    }),
    getActiveCount: publicProcedure.query(async () => {
      const count = await getActiveCount();
      return { count };
    }),
  }),

  stripe: router({
    createCheckout: publicProcedure
      .input(z.object({ priceId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const origin = (ctx.req.headers.origin as string) || 'https://localhost:3000';
          const priceId = STRIPE_PRICES[input.priceId] || STRIPE_PRICES.pro;

          const session = await stripe.checkout.sessions.create({
            line_items: [
              {
                price: priceId,
                quantity: 1,
              },
            ],
            mode: 'subscription',
            success_url: `${origin}/?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${origin}/subscribe`,
            customer_email: ctx.user?.email || undefined,
            metadata: {
              user_id: ctx.user?.id?.toString() || 'anonymous',
              user_name: ctx.user?.name || 'User',
            },
          });

          return {
            checkoutUrl: session.url,
            sessionId: session.id,
          };
        } catch (error) {
          console.error('Stripe checkout error:', error);
          throw new Error('Failed to create checkout session');
        }
      }),
  }),

  ai: router({
    chat: publicProcedure
      .input(z.object({ message: z.string(), code: z.string().optional() }))
      .mutation(async ({ input }) => {
        try {
          const systemPrompt = `You are an expert coding assistant for the Aura Nova learning platform. You help developers:
- Debug and fix code issues
- Explain programming concepts
- Suggest code improvements
- Automate repetitive tasks
- Provide best practices
- Answer coding questions

Be concise, helpful, and provide code examples when relevant. Format code in markdown blocks.`;

          const userMessage = input.code 
            ? `${input.message}\n\nCurrent code:\n\`\`\`\n${input.code}\n\`\`\`` 
            : input.message;

          const response = await invokeLLM({
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: userMessage },
            ],
          });

          const content = response.choices[0]?.message?.content || 'No response';
          return { response: content };
        } catch (error) {
          console.error('AI chat error:', error);
          throw new Error('Failed to get AI response');
        }
      }),

    suggestImprovements: publicProcedure
      .input(z.object({ code: z.string(), language: z.string() }))
      .mutation(async ({ input }) => {
        try {
          const response = await invokeLLM({
            messages: [
              { 
                role: 'system', 
                content: 'You are a code optimization expert. Analyze the provided code and suggest improvements for performance, readability, and best practices. Format your response as a numbered list.' 
              },
              { 
                role: 'user', 
                content: `Analyze this ${input.language} code and suggest improvements:\n\`\`\`${input.language}\n${input.code}\n\`\`\`` 
              },
            ],
          });

          const content = response.choices[0]?.message?.content || 'No suggestions';
          return { suggestions: content };
        } catch (error) {
          console.error('AI suggestions error:', error);
          throw new Error('Failed to get suggestions');
        }
      }),

    debugCode: publicProcedure
      .input(z.object({ code: z.string(), error: z.string(), language: z.string() }))
      .mutation(async ({ input }) => {
        try {
          const response = await invokeLLM({
            messages: [
              { 
                role: 'system', 
                content: 'You are an expert debugger. Help fix the code error. Provide the corrected code and explain what was wrong.' 
              },
              { 
                role: 'user', 
                content: `Fix this ${input.language} code error:\n\nError: ${input.error}\n\nCode:\n\`\`\`${input.language}\n${input.code}\n\`\`\`` 
              },
            ],
          });

          const content = response.choices[0]?.message?.content || 'Unable to debug';
          return { solution: content };
        } catch (error) {
          console.error('AI debug error:', error);
          throw new Error('Failed to debug code');
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
