import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Zap, Bug, Lightbulb, X, Minimize2, Maximize2 } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

interface AIAssistantProps {
  code?: string;
  language?: string;
  onClose?: () => void;
}

export default function AIAssistant({ code = '', language = 'html', onClose }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hi! I\'m your AI coding assistant. I can help you debug code, suggest improvements, answer questions, and automate tasks. What would you like help with?',
      timestamp: new Date().toLocaleTimeString(),
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatMutation = trpc.ai.chat.useMutation();
  const suggestMutation = trpc.ai.suggestImprovements.useMutation();
  const debugMutation = trpc.ai.debugCode.useMutation();

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const addMessage = (role: 'user' | 'assistant', content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      role,
      content,
      timestamp: new Date().toLocaleTimeString(),
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    setInput('');
    addMessage('user', userMessage);
    setLoading(true);

    try {
      const result = await chatMutation.mutateAsync({
        message: userMessage,
        code: code || undefined,
      });
      const responseText = typeof result.response === 'string' ? result.response : JSON.stringify(result.response);
      addMessage('assistant', responseText);
    } catch (error: any) {
      addMessage('assistant', `Sorry, I encountered an error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSuggestImprovements = async () => {
    if (!code) {
      addMessage('assistant', 'Please write some code first, then I can suggest improvements!');
      return;
    }

    addMessage('user', 'Can you suggest improvements for my code?');
    setLoading(true);

    try {
      const result = await suggestMutation.mutateAsync({
        code,
        language,
      });
      const suggestionsText = typeof result.suggestions === 'string' ? result.suggestions : JSON.stringify(result.suggestions);
      addMessage('assistant', suggestionsText);
    } catch (error: any) {
      addMessage('assistant', `Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleDebugCode = async () => {
    if (!code) {
      addMessage('assistant', 'Please write some code first!');
      return;
    }

    addMessage('user', 'Can you help me debug this code?');
    setLoading(true);

    try {
      const result = await debugMutation.mutateAsync({
        code,
        error: 'Code review requested',
        language,
      });
      const solutionText = typeof result.solution === 'string' ? result.solution : JSON.stringify(result.solution);
      addMessage('assistant', solutionText);
    } catch (error: any) {
      addMessage('assistant', `Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 z-40">
        <button
          onClick={() => setIsMinimized(false)}
          className="flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-105"
        >
          <Zap className="w-5 h-5" />
          <span className="font-semibold">AI Assistant</span>
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 w-96 h-96 z-40 bg-card border border-border rounded-xl shadow-2xl flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-yellow-300" />
          <h3 className="font-bold text-white">AI Assistant</h3>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 hover:bg-white/20 rounded transition"
          >
            <Minimize2 className="w-4 h-4 text-white" />
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 hover:bg-white/20 rounded transition"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex gap-2 px-3 py-2 bg-background/50 border-b border-border flex-wrap">
        <button
          onClick={handleSuggestImprovements}
          disabled={loading || !code}
          className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-500/20 text-blue-300 border border-blue-400/50 rounded hover:bg-blue-500/30 transition disabled:opacity-50"
        >
          <Lightbulb className="w-3 h-3" />
          Improve
        </button>
        <button
          onClick={handleDebugCode}
          disabled={loading || !code}
          className="flex items-center gap-1 px-2 py-1 text-xs bg-red-500/20 text-red-300 border border-red-400/50 rounded hover:bg-red-500/30 transition disabled:opacity-50"
        >
          <Bug className="w-3 h-3" />
          Debug
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-background border border-border text-foreground'
              }`}
            >
              <p className="break-words whitespace-pre-wrap">{msg.content}</p>
              <span className="text-xs opacity-70 mt-1 block">{msg.timestamp}</span>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-background border border-border px-3 py-2 rounded-lg flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
              <span className="text-sm text-muted-foreground">Thinking...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-border p-3 bg-background/50">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask me anything..."
            disabled={loading}
            className="flex-1 px-3 py-2 bg-background border border-border rounded-lg text-sm focus:outline-none focus:border-blue-400 disabled:opacity-50"
          />
          <button
            onClick={handleSendMessage}
            disabled={loading || !input.trim()}
            className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
