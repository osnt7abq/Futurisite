import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Courses from "./pages/Courses";
import Workspace from "./pages/Workspace";
import Subscribe from "./pages/Subscribe";
import AIAssistantPage from "./pages/AIAssistantPage";
import ProjectResults from "./pages/ProjectResults";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/courses"} component={Courses} />
      <Route path={"/workspace"} component={Workspace} />
      <Route path={"/subscribe"} component={Subscribe} />
      <Route path={"/ai-assistant"} component={AIAssistantPage} />
      <Route path={"/project-results"} component={ProjectResults} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

/**
 * Aura Nova Edition - Digital Renaissance Theme
 * Dark theme with neon green accents and gold highlights
 * Premium, sophisticated aesthetic with smooth animations
 */
function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
