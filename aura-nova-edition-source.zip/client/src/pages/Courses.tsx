import { ArrowLeft, Code2, BookOpen, Zap, Trophy, Users, GitBranch } from 'lucide-react';
import { useLocation } from 'wouter';

export default function Courses() {
  const [, setLocation] = useLocation();

  const courses = [
    {
      id: 1,
      title: 'Web Development Fundamentals',
      level: 'Beginner',
      duration: '8 weeks',
      students: '12,500+',
      description: 'Learn HTML, CSS, and JavaScript from scratch',
      topics: ['HTML5', 'CSS3', 'JavaScript ES6+', 'Responsive Design'],
      projects: ['Personal Portfolio', 'Todo App', 'Weather App']
    },
    {
      id: 2,
      title: 'React & Modern Frontend',
      level: 'Intermediate',
      duration: '10 weeks',
      students: '8,300+',
      description: 'Master React, hooks, and state management',
      topics: ['React Basics', 'Hooks', 'Redux', 'Next.js'],
      projects: ['E-commerce Site', 'Social Media App', 'Dashboard']
    },
    {
      id: 3,
      title: 'Backend Development with Node.js',
      level: 'Intermediate',
      duration: '10 weeks',
      students: '6,200+',
      description: 'Build scalable server-side applications',
      topics: ['Express.js', 'Databases', 'APIs', 'Authentication'],
      projects: ['REST API', 'Chat Application', 'Blog Platform']
    },
    {
      id: 4,
      title: 'Full Stack Development',
      level: 'Advanced',
      duration: '12 weeks',
      students: '4,100+',
      description: 'Become a full-stack developer',
      topics: ['Frontend', 'Backend', 'Databases', 'DevOps'],
      projects: ['SaaS Application', 'Marketplace', 'Real-time App']
    },
    {
      id: 5,
      title: 'UI/UX Design Principles',
      level: 'Beginner',
      duration: '6 weeks',
      students: '5,800+',
      description: 'Design beautiful and functional interfaces',
      topics: ['Design Thinking', 'Figma', 'Prototyping', 'User Research'],
      projects: ['Design System', 'Mobile App Design', 'Website Redesign']
    },
    {
      id: 6,
      title: 'DevOps & Cloud Deployment',
      level: 'Advanced',
      duration: '8 weeks',
      students: '3,200+',
      description: 'Deploy and manage applications in the cloud',
      topics: ['Docker', 'Kubernetes', 'AWS', 'CI/CD'],
      projects: ['Containerized App', 'Cloud Deployment', 'Monitoring Setup']
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => setLocation('/')}
            className="flex items-center gap-2 text-blue-300 hover:text-blue-200 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Back</span>
          </button>
          <h1 className="text-2xl font-bold text-blue-300">Learning Paths</h1>
          <div className="w-20"></div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-24 pb-16">
        <div className="container">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6" style={{ color: '#B8D4F1' }}>
              Choose Your Learning Path
            </h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto">
              Select a course and start building real projects. Learn by doing with hands-on coding challenges.
            </p>
          </div>

          {/* Courses Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course) => (
              <div
                key={course.id}
                className="group p-8 bg-card border border-border rounded-xl hover:border-blue-400/50 transition-all duration-300 hover:bg-card/80 cursor-pointer"
              >
                {/* Course Header */}
                <div className="mb-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold mb-2" style={{ color: '#B8D4F1' }}>
                        {course.title}
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="inline-block px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs font-semibold">
                          {course.level}
                        </span>
                        <span className="text-muted-foreground text-sm">{course.duration}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-4">{course.description}</p>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-2 mb-6 pb-6 border-b border-border">
                  <Users className="w-4 h-4 text-blue-400" />
                  <span className="text-sm text-muted-foreground">{course.students} students</span>
                </div>

                {/* Topics */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-blue-300 mb-3">Topics Covered</h4>
                  <div className="flex flex-wrap gap-2">
                    {course.topics.map((topic, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-blue-500/10 text-blue-300 rounded text-xs"
                      >
                        {topic}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Projects */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-blue-300 mb-3">Build These Projects</h4>
                  <ul className="space-y-2">
                    {course.projects.map((project, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Code2 className="w-4 h-4 text-blue-400" />
                        {project}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA Button */}
                <a href="/workspace" className="w-full px-4 py-3 bg-blue-500 text-white rounded-lg font-semibold hover:bg-blue-600 transition-all duration-300 group-hover:scale-105 inline-block text-center">
                  Start Learning
                </a>
              </div>
            ))}
          </div>

          {/* Code Editor Section */}
          <div className="mt-20 pt-20 border-t border-border">
            <div className="text-center mb-12">
              <h2 className="text-4xl lg:text-5xl font-bold mb-6" style={{ color: '#B8D4F1' }}>
                Code & Build in Real-Time
              </h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Write code, see results instantly, and build real projects. Our integrated code editor supports all major programming languages.
              </p>
            </div>

            {/* Code Editor Preview */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="bg-gradient-to-r from-blue-900/20 to-blue-800/20 px-6 py-4 border-b border-border flex items-center gap-3">
                <Code2 className="w-5 h-5 text-blue-400" />
                <span className="font-mono text-sm text-blue-300">index.html</span>
              </div>
              <div className="p-8">
                <div className="font-mono text-sm text-muted-foreground space-y-2 mb-8">
                  <div><span style={{ color: '#B8D4F1' }}>&lt;!DOCTYPE html&gt;</span></div>
                  <div><span style={{ color: '#B8D4F1' }}>&lt;html&gt;</span></div>
                  <div className="ml-4"><span style={{ color: '#B8D4F1' }}>&lt;head&gt;</span></div>
                  <div className="ml-8"><span style={{ color: '#B8D4F1' }}>&lt;title&gt;</span><span>My First Project</span><span style={{ color: '#B8D4F1' }}>&lt;/title&gt;</span></div>
                  <div className="ml-4"><span style={{ color: '#B8D4F1' }}>&lt;/head&gt;</span></div>
                  <div className="ml-4"><span style={{ color: '#B8D4F1' }}>&lt;body&gt;</span></div>
                  <div className="ml-8"><span style={{ color: '#B8D4F1' }}>&lt;h1&gt;</span><span>Welcome to Aura Nova</span><span style={{ color: '#B8D4F1' }}>&lt;/h1&gt;</span></div>
                  <div className="ml-4"><span style={{ color: '#B8D4F1' }}>&lt;/body&gt;</span></div>
                  <div><span style={{ color: '#B8D4F1' }}>&lt;/html&gt;</span></div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div>
                    <h4 className="text-sm font-semibold text-blue-300 mb-4">Features</h4>
                    <ul className="space-y-3">
                      {[
                        'Live Code Editor',
                        'Real-time Preview',
                        'Syntax Highlighting',
                        'Code Completion',
                        'Multiple Languages',
                        'Version Control'
                      ].map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-muted-foreground">
                          <Zap className="w-4 h-4 text-blue-400" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-blue-300 mb-4">Learning Tools</h4>
                    <ul className="space-y-3">
                      {[
                        'Interactive Tutorials',
                        'Code Challenges',
                        'Project Templates',
                        'Peer Review System',
                        'Expert Mentorship',
                        'Community Support'
                      ].map((tool, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-muted-foreground">
                          <BookOpen className="w-4 h-4 text-blue-400" />
                          {tool}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-20 text-center">
            <h3 className="text-3xl font-bold mb-6" style={{ color: '#B8D4F1' }}>
              Ready to Start Coding?
            </h3>
            <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
              Join thousands of developers learning and building amazing projects. Your first month is just $1.
            </p>
            <button className="px-12 py-4 bg-blue-500 text-white rounded-lg font-bold text-lg hover:bg-blue-600 transition-all duration-300 hover:scale-105">
              Start Your Journey for $1
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
