import { useState, useEffect } from 'react';
import { ArrowLeft, Download, Share2, Globe, Loader2 } from 'lucide-react';
import { useLocation } from 'wouter';

interface Project {
  id: string;
  name: string;
  description: string;
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  createdAt: string;
  isPublished: boolean;
  publishUrl?: string;
}

export default function ProjectResults() {
  const [, setLocation] = useLocation();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [publishing, setPublishing] = useState(false);
  const [projectName, setProjectName] = useState('My Awesome Project');
  const [projectDescription, setProjectDescription] = useState('Built with Aura Nova');

  useEffect(() => {
    // Load last saved project from localStorage
    const savedProject = localStorage.getItem('lastProject');
    if (savedProject) {
      try {
        const parsed = JSON.parse(savedProject);
        setProject(parsed);
        setProjectName(parsed.name || 'My Awesome Project');
        setProjectDescription(parsed.description || 'Built with Aura Nova');
      } catch (error) {
        console.error('Error loading project:', error);
      }
    }
    setLoading(false);
  }, []);

  const handlePublish = async () => {
    if (!project) return;
    setPublishing(true);

    try {
      // Generate a unique URL for the project
      const projectId = Date.now().toString();
      const publishUrl = `/project/${projectId}`;

      // Update project with publish info
      const updatedProject = {
        ...project,
        isPublished: true,
        publishUrl,
      };

      // Save to localStorage
      localStorage.setItem(`project_${projectId}`, JSON.stringify(updatedProject));
      localStorage.setItem('lastProject', JSON.stringify(updatedProject));

      setProject(updatedProject);

      // Show success message
      alert(`🎉 Project published!\n\nShare this link:\n${window.location.origin}${publishUrl}`);
    } catch (error) {
      console.error('Error publishing project:', error);
      alert('Failed to publish project');
    } finally {
      setPublishing(false);
    }
  };

  const handleDownload = () => {
    if (!project) return;

    const fullCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${projectName}</title>
  <style>
${project.cssCode}
  </style>
</head>
<body>
${project.htmlCode}
  <script>
${project.jsCode}
  </script>
</body>
</html>`;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/html;charset=utf-8,' + encodeURIComponent(fullCode));
    element.setAttribute('download', `${projectName.replace(/\s+/g, '-')}.html`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleShare = () => {
    if (project?.publishUrl) {
      const shareUrl = `${window.location.origin}${project.publishUrl}`;
      navigator.clipboard.writeText(shareUrl);
      alert('Project link copied to clipboard!');
    } else {
      alert('Please publish your project first to share it!');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
          <p className="text-muted-foreground">Loading your project...</p>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <div className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
          <div className="container flex items-center py-4">
            <button
              onClick={() => setLocation('/workspace')}
              className="flex items-center gap-2 text-blue-300 hover:text-blue-200 transition"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-semibold">Back to Workspace</span>
            </button>
          </div>
        </div>

        <div className="pt-20 pb-8 px-4 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-blue-300 mb-4">No Project Found</h1>
            <p className="text-muted-foreground mb-6">Build something amazing in the workspace first!</p>
            <button
              onClick={() => setLocation('/workspace')}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold"
            >
              Go to Workspace
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => setLocation('/workspace')}
            className="flex items-center gap-2 text-blue-300 hover:text-blue-200 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Back to Workspace</span>
          </button>
          <h1 className="text-2xl font-bold text-blue-300">Project Results</h1>
          <div className="w-40"></div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-20 pb-8 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Project Info */}
          <div className="bg-card border border-border rounded-xl p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-sm font-semibold text-blue-300 mb-2">Project Name</label>
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:border-blue-400"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-blue-300 mb-2">Description</label>
                <input
                  type="text"
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                  className="w-full px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:border-blue-400"
                />
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center gap-2 mb-4">
              {project.isPublished ? (
                <>
                  <Globe className="w-5 h-5 text-green-400" />
                  <span className="text-green-400 font-semibold">Published</span>
                  {project.publishUrl && (
                    <a
                      href={project.publishUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:text-blue-300 underline text-sm"
                    >
                      View Live
                    </a>
                  )}
                </>
              ) : (
                <>
                  <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                  <span className="text-yellow-400 font-semibold">Not Published</span>
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 flex-wrap">
              <button
                onClick={handlePublish}
                disabled={publishing || project.isPublished}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:shadow-lg transition disabled:opacity-50 font-semibold"
              >
                {publishing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Publishing...
                  </>
                ) : (
                  <>
                    <Globe className="w-4 h-4" />
                    {project.isPublished ? 'Published' : 'Publish Project'}
                  </>
                )}
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center gap-2 px-6 py-3 bg-blue-500/20 text-blue-300 border border-blue-400/50 rounded-lg hover:bg-blue-500/30 transition font-semibold"
              >
                <Download className="w-4 h-4" />
                Download
              </button>
              <button
                onClick={handleShare}
                className="flex items-center gap-2 px-6 py-3 bg-purple-500/20 text-purple-300 border border-purple-400/50 rounded-lg hover:bg-purple-500/30 transition font-semibold"
              >
                <Share2 className="w-4 h-4" />
                Share
              </button>
            </div>
          </div>

          {/* Project Preview */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 px-6 py-4 border-b border-border">
              <h2 className="text-lg font-semibold text-blue-300">Live Preview</h2>
            </div>
            <div className="relative bg-white/5 aspect-video">
              <iframe
                srcDoc={`
                  <!DOCTYPE html>
                  <html>
                  <head>
                    <style>${project.cssCode}</style>
                  </head>
                  <body>
                    ${project.htmlCode}
                    <script>${project.jsCode}</script>
                  </body>
                  </html>
                `}
                className="w-full h-full border-0"
                title="Project Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </div>

          {/* Code Display */}
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* HTML */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="bg-blue-900/20 px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold text-blue-300">HTML</h3>
              </div>
              <pre className="p-4 text-xs text-muted-foreground overflow-auto max-h-48 bg-background/50">
                <code>{project.htmlCode}</code>
              </pre>
            </div>

            {/* CSS */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="bg-green-900/20 px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold text-green-300">CSS</h3>
              </div>
              <pre className="p-4 text-xs text-muted-foreground overflow-auto max-h-48 bg-background/50">
                <code>{project.cssCode}</code>
              </pre>
            </div>

            {/* JavaScript */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="bg-yellow-900/20 px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold text-yellow-300">JavaScript</h3>
              </div>
              <pre className="p-4 text-xs text-muted-foreground overflow-auto max-h-48 bg-background/50">
                <code>{project.jsCode}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
