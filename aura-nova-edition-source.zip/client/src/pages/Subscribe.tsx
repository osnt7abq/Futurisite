import { useState } from 'react';
import { ArrowLeft, CreditCard, Smartphone, Wallet, DollarSign, Check } from 'lucide-react';
import { useLocation } from 'wouter';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Subscribe() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState('pro');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [loading, setLoading] = useState(false);

  const createCheckoutMutation = trpc.stripe.createCheckout.useMutation();

  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      price: 1,
      period: 'first month',
      then: '$4.99/month after',
      features: [
        'Access to 50+ courses',
        'Basic code editor',
        'Community support',
        'Certificate of completion',
        'Mobile app access'
      ],
      highlighted: false
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 1,
      period: 'first month',
      then: '$9.99/month after',
      features: [
        'All Starter features',
        'Advanced code editor',
        'Priority support',
        'Live mentorship',
        'Project portfolio builder',
        'Expert code reviews',
        'Job board access',
        'Unlimited projects'
      ],
      highlighted: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: 1,
      period: 'first month',
      then: '$19.99/month after',
      features: [
        'All Pro features',
        'Team collaboration',
        'Custom learning paths',
        'Dedicated mentor',
        'Private community',
        'API access',
        'Custom integrations',
        'Priority feature requests'
      ],
      highlighted: false
    }
  ];

  const paymentMethods = [
    {
      id: 'card',
      name: 'Credit/Debit Card',
      icon: CreditCard,
      description: 'Visa, Mastercard, American Express',
      supported: true
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: Wallet,
      description: 'Fast and secure PayPal checkout',
      supported: true
    },
    {
      id: 'apple',
      name: 'Apple Pay',
      icon: Smartphone,
      description: 'Quick payment with Apple Pay',
      supported: true
    },
    {
      id: 'google',
      name: 'Google Pay',
      icon: Smartphone,
      description: 'Quick payment with Google Pay',
      supported: true
    }
  ];

  const handleSubscribe = async () => {
    if (!isAuthenticated) {
      alert('Please log in to subscribe');
      return;
    }

    setLoading(true);
    try {
      const result = await createCheckoutMutation.mutateAsync({
        priceId: selectedPlan,
      });

      if (result.checkoutUrl) {
        window.open(result.checkoutUrl, '_blank');
      }
    } catch (error) {
      console.error('Subscription error:', error);
      alert('Failed to start checkout. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const currentPlan = plans.find(p => p.id === selectedPlan);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => setLocation('/')}
            className="flex items-center gap-2 text-blue-300 hover:text-blue-200 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Back to Home</span>
          </button>
          <h1 className="text-2xl font-bold text-blue-300 flex items-center gap-2">
            <DollarSign className="w-6 h-6" />
            Choose Your Plan
          </h1>
          <div className="w-40"></div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-16">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6" style={{ color: '#B8D4F1' }}>
              Simple, Transparent Pricing
            </h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto">
              Start with just $1 for your first month. Cancel anytime. No hidden fees.
            </p>
          </div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {plans.map((plan) => (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id)}
                className={`relative rounded-xl border transition-all duration-300 cursor-pointer overflow-hidden ${
                  selectedPlan === plan.id
                    ? 'border-blue-400 bg-card/80 ring-2 ring-blue-400'
                    : 'border-border bg-card hover:border-blue-400/50'
                }`}
              >
                {plan.highlighted && (
                  <div className="absolute top-0 right-0 bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-1 text-xs font-bold rounded-bl-lg">
                    MOST POPULAR
                  </div>
                )}

                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-2" style={{ color: '#B8D4F1' }}>
                    {plan.name}
                  </h3>

                  <div className="mb-6">
                    <div className="flex items-baseline gap-1 mb-2">
                      <span className="text-5xl font-bold text-blue-400">${plan.price}</span>
                      <span className="text-muted-foreground">/{plan.period}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{plan.then}</p>
                  </div>

                  <button
                    onClick={handleSubscribe}
                    disabled={loading}
                    className={`w-full px-6 py-3 rounded-lg font-bold mb-8 transition-all duration-300 ${
                      selectedPlan === plan.id
                        ? 'bg-blue-500 text-white hover:bg-blue-600'
                        : 'bg-blue-500/20 text-blue-300 border border-blue-400/50 hover:bg-blue-500/30'
                    } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    {loading ? 'Processing...' : 'Subscribe Now'}
                  </button>

                  <div className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Payment Methods */}
          <div className="bg-card border border-border rounded-xl p-8 mb-16">
            <h3 className="text-2xl font-bold mb-8" style={{ color: '#B8D4F1' }}>
              Choose Payment Method
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {paymentMethods.map((method) => {
                const Icon = method.icon;
                return (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id)}
                    className={`p-6 rounded-lg border-2 transition-all duration-300 text-left ${
                      paymentMethod === method.id
                        ? 'border-blue-400 bg-blue-500/10'
                        : 'border-border hover:border-blue-400/50'
                    } ${!method.supported ? 'opacity-50 cursor-not-allowed' : ''}`}
                    disabled={!method.supported}
                  >
                    <Icon className="w-8 h-8 text-blue-400 mb-3" />
                    <h4 className="font-bold text-white mb-1">{method.name}</h4>
                    <p className="text-xs text-muted-foreground">{method.description}</p>
                    {!method.supported && (
                      <p className="text-xs text-red-400 mt-2">Coming soon</p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* FAQ Section */}
          <div className="bg-card border border-border rounded-xl p-8">
            <h3 className="text-2xl font-bold mb-8" style={{ color: '#B8D4F1' }}>
              Frequently Asked Questions
            </h3>

            <div className="space-y-6">
              <div>
                <h4 className="font-bold text-blue-300 mb-2">Can I cancel anytime?</h4>
                <p className="text-muted-foreground">
                  Yes! You can cancel your subscription at any time. No questions asked, no hidden fees.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-blue-300 mb-2">What payment methods do you accept?</h4>
                <p className="text-muted-foreground">
                  We accept all major credit cards (Visa, Mastercard, American Express), PayPal, Apple Pay, and Google Pay.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-blue-300 mb-2">Is my payment information secure?</h4>
                <p className="text-muted-foreground">
                  Yes! We use Stripe, a PCI-compliant payment processor, to securely handle all transactions. Your payment information is never stored on our servers.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-blue-300 mb-2">Can I upgrade or downgrade my plan?</h4>
                <p className="text-muted-foreground">
                  Absolutely! You can change your plan at any time. We'll prorate the charges based on your usage.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-blue-300 mb-2">Do you offer refunds?</h4>
                <p className="text-muted-foreground">
                  We offer a 7-day money-back guarantee if you're not satisfied with your subscription.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-blue-300 mb-2">What's included in each plan?</h4>
                <p className="text-muted-foreground">
                  Check the features listed in the pricing cards above. Each plan includes everything from the lower tiers plus additional features.
                </p>
              </div>
            </div>
          </div>

          {/* Trust Badges */}
          <div className="mt-16 text-center">
            <p className="text-muted-foreground mb-6">Trusted by developers worldwide</p>
            <div className="flex justify-center items-center gap-8 flex-wrap">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">50K+</div>
                <p className="text-sm text-muted-foreground">Active Members</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">99.9%</div>
                <p className="text-sm text-muted-foreground">Uptime</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">24/7</div>
                <p className="text-sm text-muted-foreground">Support</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
