import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Play, Save, Copy, Download, Trash2, Code2, Terminal, X, Zap, Globe } from 'lucide-react';
import { useLocation } from 'wouter';
import AIAssistant from '@/components/AIAssistant';

interface ConsoleLog {
  type: 'log' | 'error' | 'warn' | 'info';
  message: string;
  timestamp: string;
}

export default function Workspace() {
  const [, setLocation] = useLocation();
  const [htmlCode, setHtmlCode] = useState(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Project</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      margin: 0;
      padding: 20px;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .container {
      background: white;
      border-radius: 10px;
      padding: 40px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      text-align: center;
    }
    h1 {
      color: #333;
      margin: 0 0 10px 0;
    }
    p {
      color: #666;
      font-size: 16px;
    }
    button {
      background: #667eea;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 20px;
    }
    button:hover {
      background: #764ba2;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to Aura Nova!</h1>
    <p>Edit the HTML code on the left to see changes here in real-time.</p>
    <button onclick="alert('You clicked the button!')">Click Me!</button>
  </div>
</body>
</html>`);

  const [cssCode, setCssCode] = useState('/* Add your CSS here */');
  const [jsCode, setJsCode] = useState('// Add your JavaScript here\nconsole.log("Hello from Aura Nova!");');
  const [consoleLogs, setConsoleLogs] = useState<ConsoleLog[]>([]);
  const [showConsole, setShowConsole] = useState(true);
  const [showAI, setShowAI] = useState(false);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Auto-scroll console to bottom
  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [consoleLogs]);

  const addConsoleLog = (type: 'log' | 'error' | 'warn' | 'info', message: string) => {
    const now = new Date();
    const timestamp = now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit',
      hour12: true 
    });
    
    setConsoleLogs(prev => [...prev, { type, message, timestamp }]);
  };

  const clearConsole = () => {
    setConsoleLogs([]);
  };

  const saveProject = () => {
    const project = {
      id: Date.now().toString(),
      name: 'My Project',
      description: 'Built with Aura Nova',
      htmlCode,
      cssCode,
      jsCode,
      createdAt: new Date().toISOString(),
      isPublished: false,
    };
    localStorage.setItem('lastProject', JSON.stringify(project));
    addConsoleLog('info', '💾 Project saved successfully!');
  };

  const runCode = () => {
    clearConsole();
    addConsoleLog('info', '▶️ Running code...');

    try {
      const iframe = iframeRef.current;
      if (iframe && iframe.contentDocument && iframe.contentWindow) {
        // Override console methods in the iframe
        const iframeConsole = {
          log: (...args: any[]) => {
            const message = args.map(arg => {
              if (typeof arg === 'object') {
                return JSON.stringify(arg, null, 2);
              }
              return String(arg);
            }).join(' ');
            addConsoleLog('log', message);
          },
          error: (...args: any[]) => {
            const message = args.map(arg => {
              if (typeof arg === 'object') {
                return JSON.stringify(arg, null, 2);
              }
              return String(arg);
            }).join(' ');
            addConsoleLog('error', '❌ ' + message);
          },
          warn: (...args: any[]) => {
            const message = args.map(arg => {
              if (typeof arg === 'object') {
                return JSON.stringify(arg, null, 2);
              }
              return String(arg);
            }).join(' ');
            addConsoleLog('warn', '⚠️ ' + message);
          },
          info: (...args: any[]) => {
            const message = args.map(arg => {
              if (typeof arg === 'object') {
                return JSON.stringify(arg, null, 2);
              }
              return String(arg);
            }).join(' ');
            addConsoleLog('info', 'ℹ️ ' + message);
          },
        };

        const fullCode = `
          <script>
            window.console = {
              log: function(...args) {
                parent.postMessage({type: 'log', data: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}, '*');
              },
              error: function(...args) {
                parent.postMessage({type: 'error', data: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}, '*');
              },
              warn: function(...args) {
                parent.postMessage({type: 'warn', data: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}, '*');
              },
              info: function(...args) {
                parent.postMessage({type: 'info', data: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}, '*');
              }
            };
          </script>
          ${htmlCode}
          <style>${cssCode}</style>
          <script>${jsCode}</script>
        `;

        iframe.contentDocument.open();
        iframe.contentDocument.write(fullCode);
        iframe.contentDocument.close();

        addConsoleLog('info', '✅ Code executed successfully');
      }
    } catch (error: any) {
      addConsoleLog('error', error?.message || 'An error occurred');
    }
  };

  // Listen for messages from iframe
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data.type === 'log') {
        addConsoleLog('log', event.data.data);
      } else if (event.data.type === 'error') {
        addConsoleLog('error', event.data.data);
      } else if (event.data.type === 'warn') {
        addConsoleLog('warn', event.data.data);
      } else if (event.data.type === 'info') {
        addConsoleLog('info', event.data.data);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const copyCode = () => {
    const allCode = `${htmlCode}\n\n<style>\n${cssCode}\n</style>\n\n<script>\n${jsCode}\n</script>`;
    navigator.clipboard.writeText(allCode);
    addConsoleLog('info', '📋 Code copied to clipboard!');
  };

  const downloadCode = () => {
    const allCode = `${htmlCode}\n\n<style>\n${cssCode}\n</style>\n\n<script>\n${jsCode}\n</script>`;
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(allCode));
    element.setAttribute('download', 'project.html');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    addConsoleLog('info', '💾 Project downloaded!');
  };

  const clearCode = () => {
    if (confirm('Are you sure you want to clear all code?')) {
      setHtmlCode('');
      setCssCode('');
      setJsCode('');
      clearConsole();
      addConsoleLog('info', '🗑️ Code cleared');
    }
  };

  const getConsoleLogColor = (type: string) => {
    switch (type) {
      case 'error':
        return 'text-red-400';
      case 'warn':
        return 'text-yellow-400';
      case 'info':
        return 'text-blue-400';
      default:
        return 'text-green-400';
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <button
            onClick={() => setLocation('/courses')}
            className="flex items-center gap-2 text-blue-300 hover:text-blue-200 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-semibold">Back to Courses</span>
          </button>
          <h1 className="text-2xl font-bold text-blue-300 flex items-center gap-2">
            <Code2 className="w-6 h-6" />
            Code Workspace
          </h1>
          <div className="w-40"></div>
        </div>
      </div>

      {/* Main Content */}
      <div className="pt-20 pb-8 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Toolbar */}
          <div className="flex gap-3 mb-6 flex-wrap">
            <button
              onClick={runCode}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition font-semibold"
            >
              <Play className="w-4 h-4" />
              Run Code
            </button>
            <button
              onClick={copyCode}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-300 border border-blue-400/50 rounded-lg hover:bg-blue-500/30 transition"
            >
              <Copy className="w-4 h-4" />
              Copy
            </button>
            <button
              onClick={downloadCode}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-300 border border-blue-400/50 rounded-lg hover:bg-blue-500/30 transition"
            >
              <Download className="w-4 h-4" />
              Download
            </button>
            <button
              onClick={clearCode}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-300 border border-red-400/50 rounded-lg hover:bg-red-500/30 transition"
            >
              <Trash2 className="w-4 h-4" />
              Clear
            </button>
            <button
              onClick={() => setShowConsole(!showConsole)}
              className="flex items-center gap-2 px-4 py-2 bg-purple-500/20 text-purple-300 border border-purple-400/50 rounded-lg hover:bg-purple-500/30 transition"
            >
              <Terminal className="w-4 h-4" />
              {showConsole ? 'Hide' : 'Show'} Console
            </button>
            <button
              onClick={() => setLocation('/ai-assistant')}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition"
            >
              <Zap className="w-4 h-4" />
              AI Assistant
            </button>
            <button
              onClick={() => { saveProject(); setLocation('/project-results'); }}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:shadow-lg transition ml-auto"
            >
              <Globe className="w-4 h-4" />
              See Results
            </button>
          </div>

          {/* Editor and Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Code Editors */}
            <div className="space-y-4">
              {/* HTML Editor */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="bg-gradient-to-r from-blue-900/20 to-blue-800/20 px-4 py-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-blue-300">HTML</h3>
                </div>
                <textarea
                  value={htmlCode}
                  onChange={(e) => setHtmlCode(e.target.value)}
                  className="w-full h-48 p-4 bg-background text-foreground font-mono text-sm border-0 resize-none focus:outline-none"
                  placeholder="Enter HTML code..."
                />
              </div>

              {/* CSS Editor */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="bg-gradient-to-r from-green-900/20 to-green-800/20 px-4 py-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-green-300">CSS</h3>
                </div>
                <textarea
                  value={cssCode}
                  onChange={(e) => setCssCode(e.target.value)}
                  className="w-full h-32 p-4 bg-background text-foreground font-mono text-sm border-0 resize-none focus:outline-none"
                  placeholder="Enter CSS code..."
                />
              </div>

              {/* JavaScript Editor */}
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="bg-gradient-to-r from-yellow-900/20 to-yellow-800/20 px-4 py-3 border-b border-border">
                  <h3 className="text-sm font-semibold text-yellow-300">JavaScript</h3>
                </div>
                <textarea
                  value={jsCode}
                  onChange={(e) => setJsCode(e.target.value)}
                  className="w-full h-32 p-4 bg-background text-foreground font-mono text-sm border-0 resize-none focus:outline-none"
                  placeholder="Enter JavaScript code..."
                />
              </div>
            </div>

            {/* Preview */}
            <div className="bg-card border border-border rounded-xl overflow-hidden flex flex-col">
              <div className="bg-gradient-to-r from-purple-900/20 to-purple-800/20 px-4 py-3 border-b border-border">
                <h3 className="text-sm font-semibold text-purple-300">Preview</h3>
              </div>
              <iframe
                ref={iframeRef}
                className="flex-1 w-full border-0 bg-white"
                title="Code Preview"
                sandbox="allow-scripts"
              />
            </div>
          </div>

          {/* Console */}
          {showConsole && (
            <div className="bg-card border border-border rounded-xl overflow-hidden flex flex-col">
              <div className="bg-gradient-to-r from-gray-900/40 to-gray-800/40 px-4 py-3 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-purple-400" />
                  <h3 className="text-sm font-semibold text-purple-300">Terminal / Console</h3>
                </div>
                <button
                  onClick={clearConsole}
                  className="text-xs px-2 py-1 bg-red-500/20 text-red-300 border border-red-400/50 rounded hover:bg-red-500/30 transition"
                >
                  Clear Console
                </button>
              </div>
              <div className="h-48 overflow-y-auto bg-black/30 p-4 font-mono text-xs space-y-1">
                {consoleLogs.length === 0 ? (
                  <div className="text-gray-500">Console output will appear here...</div>
                ) : (
                  consoleLogs.map((log, idx) => (
                    <div key={idx} className={`${getConsoleLogColor(log.type)} flex gap-2`}>
                      <span className="text-gray-500 flex-shrink-0">[{log.timestamp}]</span>
                      <span className="break-words">{log.message}</span>
                    </div>
                  ))
                )}
                <div ref={consoleEndRef} />
              </div>
            </div>
          )}

          {/* Learning Tips */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="text-lg font-bold text-blue-300 mb-3">💡 Tips</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Click "Run Code" to execute</li>
                <li>• Check console for output</li>
                <li>• Use console.log() to debug</li>
                <li>• Save your work regularly</li>
              </ul>
            </div>

            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="text-lg font-bold text-green-300 mb-3">🎯 Challenge</h4>
              <p className="text-sm text-muted-foreground mb-3">
                Try creating a calculator, todo list, or interactive game!
              </p>
              <button className="w-full px-4 py-2 bg-green-500/20 text-green-300 border border-green-400/50 rounded-lg hover:bg-green-500/30 transition text-sm font-semibold">
                View Challenges
              </button>
            </div>

            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="text-lg font-bold text-purple-300 mb-3">📚 Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• <a href="#" className="text-blue-400 hover:text-blue-300">MDN Web Docs</a></li>
                <li>• <a href="#" className="text-blue-400 hover:text-blue-300">W3Schools</a></li>
                <li>• <a href="#" className="text-blue-400 hover:text-blue-300">Stack Overflow</a></li>
                <li>• <a href="#" className="text-blue-400 hover:text-blue-300">GitHub</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>


    </div>
  );
}
