import { useEffect, useState } from 'react';
import { Code2, Users, Zap, Trophy, BookOpen, ChevronDown, GitBranch, Cpu, Palette, Cloud, Clock } from 'lucide-react';
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

/**
 * Aura Nova Edition - Developer Learning Platform
 * 
 * Features:
 * - Real-time clock display
 * - Live weather information
 * - Developer learning platform ($1 membership)
 * - Aesthetic blue color scheme (no neon green)
 */

// Grid overlay component
const GridOverlay = ({ opacity = 0.1 }) => (
  <div className="absolute inset-0 pointer-events-none" style={{ opacity }}>
    <div style={{ backgroundImage: 'linear-gradient(0deg, transparent 24%, rgba(100, 200, 255, 0.1) 25%, rgba(100, 200, 255, 0.1) 26%, transparent 27%, transparent 74%, rgba(100, 200, 255, 0.1) 75%, rgba(100, 200, 255, 0.1) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(100, 200, 255, 0.1) 25%, rgba(100, 200, 255, 0.1) 26%, transparent 27%, transparent 74%, rgba(100, 200, 255, 0.1) 75%, rgba(100, 200, 255, 0.1) 76%, transparent 77%, transparent)', backgroundSize: '50px 50px', width: '100%', height: '100%' }} />
  </div>
);

// Real-time Clock Component
const RealtimeClock = () => {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: true 
      }));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-transparent">
      <Clock className="w-4 h-4 text-blue-400" />
      <span className="text-blue-300 font-mono text-xs">{time || '00:00:00'}</span>
    </div>
  );
};

// Weather Component
const WeatherWidget = () => {
  const [weather, setWeather] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        // Using Open-Meteo API (free, no key required)
        const response = await fetch(
          'https://api.open-meteo.com/v1/forecast?latitude=0&longitude=0&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto'
        );
        const data = await response.json();
        setWeather(data.current);
      } catch (error) {
        console.error('Weather fetch failed:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchWeather();
    const interval = setInterval(fetchWeather, 600000); // Update every 10 minutes
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-transparent">
        <Cloud className="w-4 h-4 text-blue-400 animate-pulse" />
        <span className="text-blue-300 text-xs">Loading...</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-transparent">
      <Cloud className="w-4 h-4 text-blue-400" />
      <span className="text-blue-300 text-xs">
        {weather?.temperature_2m}°C • {weather?.wind_speed_10m}km/h
      </span>
    </div>
  );
};

export default function Home() {
  const { user, logout, isAuthenticated } = useAuth();
  const [scrollY, setScrollY] = useState(0);
  const [sessionId, setSessionId] = useState<string>('');

  // Track active session and get active count
  const trackSessionMutation = trpc.community.trackSession.useMutation();
  const { data: activeData, refetch: refetchActive } = trpc.community.getActiveCount.useQuery(undefined, {
    refetchInterval: 5000, // Refetch every 5 seconds
  });

  useEffect(() => {
    // Track this session on mount
    trackSessionMutation.mutate(undefined, {
      onSuccess: (data) => {
        setSessionId(data.sessionId);
      },
    });

    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const activeCount = activeData?.count || 0;

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Code2 className="w-6 h-6 text-blue-400" />
              <span className="text-xl font-bold text-blue-300">AURA NOVA</span>
            </div>
            <div className="flex items-center gap-3">
              <RealtimeClock />
              <WeatherWidget />
            </div>
          </div>
          <button className="px-5 py-2 bg-blue-500 text-white rounded-md font-semibold text-sm hover:bg-blue-600 transition-all duration-300 hover:scale-105">
            Join for $1
          </button>
        </div>
      </nav>

      {/* HERO SECTION */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Dark gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background/80 to-background z-0" />

        {/* Grid overlay */}
        <GridOverlay opacity={0.15} />

        {/* Animated accent lines */}
        <div className="absolute top-1/4 right-0 w-1 h-64 bg-gradient-to-b from-blue-400 via-blue-500/50 to-transparent z-2 animate-pulse" />
        <div className="absolute bottom-1/4 left-0 w-1 h-64 bg-gradient-to-t from-blue-400 via-blue-500/50 to-transparent z-2 animate-pulse" style={{ animationDelay: '1s' }} />

        {/* Floating elements */}
        <div 
          className="absolute top-20 right-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-float z-1" 
          style={{ transform: `translateY(${scrollY * 0.5}px)` }}
        />
        <div 
          className="absolute bottom-20 left-10 w-96 h-96 bg-blue-400/5 rounded-full blur-3xl animate-float z-1" 
          style={{ animationDelay: '2s', transform: `translateY(${scrollY * 0.3}px)` }}
        />

        {/* Content */}
        <div className="container relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block mb-6 px-4 py-2 bg-blue-500/10 border border-blue-400/30 rounded-full animate-fade-in">
              <span className="text-blue-300 text-sm font-semibold">💻 Developer Community</span>
            </div>
            
            <h1 className="text-6xl lg:text-8xl font-bold mb-8 leading-tight animate-fade-in">
              <span style={{ color: '#B8D4F1' }}>Learn.</span>
              <br />
              <span style={{ color: '#B8D4F1' }}>Build.</span>
              <br />
              <span style={{ color: '#B8D4F1' }}>Create.</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl leading-relaxed animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Join a thriving community of developers. Learn to code, build amazing projects, and collaborate with thousands of creators. All for just $1.
            </p>
            
            <div className="flex gap-4 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <a href="/subscribe" className="px-8 py-4 bg-blue-500 text-white rounded-lg font-bold hover:bg-blue-600 transition-all duration-300 hover:scale-105 inline-flex items-center gap-2">
                Join Now for $1 →
              </a>
              <a href="/courses" className="px-8 py-4 border border-blue-400/50 text-blue-300 rounded-lg font-bold hover:bg-blue-500/10 transition-all duration-300 inline-block">
                Explore Courses
              </a>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce z-10">
          <ChevronDown className="w-6 h-6 text-blue-400/50" />
        </div>
      </section>

      {/* LEARNING PATHS */}
      <section className="relative py-32 bg-gradient-dark overflow-hidden">
        <div className="container">
          <div className="text-center mb-20">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 animate-fade-in" style={{ color: '#B8D4F1' }}>
              Learning Paths
            </h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Choose your journey. Master web development, mobile apps, data science, and more.
            </p>
          </div>

          {/* Learning Path Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Code2, title: 'Web Development', desc: 'HTML, CSS, JavaScript, React, Node.js', level: 'Beginner to Advanced' },
              { icon: Cpu, title: 'Backend Development', desc: 'APIs, Databases, Server Architecture', level: 'Intermediate to Advanced' },
              { icon: Palette, title: 'UI/UX Design', desc: 'Design Systems, Figma, Prototyping', level: 'All Levels' },
              { icon: GitBranch, title: 'DevOps & Cloud', desc: 'Docker, Kubernetes, AWS, Azure', level: 'Intermediate to Advanced' },
              { icon: Zap, title: 'Performance & Security', desc: 'Optimization, Security Best Practices', level: 'Advanced' },
              { icon: BookOpen, title: 'Open Source', desc: 'Contribute to Real Projects', level: 'All Levels' },
            ].map((path, idx) => (
              <div
                key={idx}
                className="group p-8 bg-card border border-border rounded-xl hover:border-blue-400/50 transition-all duration-300 hover:bg-card/80 animate-fade-in"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <path.icon className="w-12 h-12 text-blue-400 mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-2xl font-bold mb-2" style={{ color: '#B8D4F1' }}>{path.title}</h3>
                <p className="text-muted-foreground mb-4">{path.desc}</p>
                <span className="text-blue-300 text-sm font-semibold">{path.level}</span>
              </div>
            ))}
          </div>
        </div>

        <GridOverlay opacity={0.05} />
      </section>

      {/* BUILD REAL PROJECTS */}
      <section className="relative py-32 overflow-hidden">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 animate-fade-in">
              <span style={{ color: '#B8D4F1' }}>Build Real</span>
              <br />
              <span style={{ color: '#B8D4F1' }}>Projects</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-12 leading-relaxed animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Don't just learn theory. Build real-world projects from day one. Create a portfolio that impresses employers and showcases your skills.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { icon: Zap, title: 'Live Coding Challenges', desc: 'Solve real problems in real-time' },
                { icon: Users, title: 'Collaborative Projects', desc: 'Work with other developers' },
                { icon: Trophy, title: 'Portfolio Builder', desc: 'Showcase your best work' },
                { icon: BookOpen, title: 'Expert Code Reviews', desc: 'Get feedback from professionals' },
              ].map((feature, idx) => (
                <div
                  key={idx}
                  className="p-6 bg-card border border-border rounded-xl hover:border-blue-400/50 transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <feature.icon className="w-10 h-10 text-blue-400 mb-4" />
                  <h3 className="text-xl font-bold mb-2" style={{ color: '#B8D4F1' }}>{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* COMMUNITY SECTION */}
      <section className="relative py-32 bg-gradient-dark overflow-hidden">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 animate-fade-in">
              <span style={{ color: '#B8D4F1' }}>Join Our</span>
              <br />
              <span style={{ color: '#B8D4F1' }}>Community</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-12 leading-relaxed animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Connect with thousands of developers worldwide. Share ideas, get help, mentor others, and grow together. Your journey is our mission.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              {[
                { icon: Users, stat: activeCount > 0 ? `${activeCount}` : '50,000+', label: activeCount > 0 ? 'Active Now' : 'Active Members' },
                { icon: Zap, stat: '10,000+', label: 'Daily Challenges' },
                { icon: Trophy, stat: '1,000+', label: 'Success Stories' },
                { icon: BookOpen, stat: '500+', label: 'Courses' },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="p-8 bg-card border border-border rounded-xl hover:border-blue-400/50 transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <item.icon className="w-12 h-12 text-blue-400 mx-auto mb-4" />
                  <div className="text-4xl font-bold mb-2" style={{ color: '#B8D4F1' }}>{item.stat}</div>
                  <p className="text-muted-foreground">{item.label}</p>
                </div>
              ))}
            </div>

            <button className="px-8 py-4 bg-blue-500 text-white rounded-lg font-bold hover:bg-blue-600 transition-all duration-300 hover:scale-105">
              Join the Community
            </button>
          </div>
        </div>

        <GridOverlay opacity={0.05} />
      </section>

      {/* PRICING SECTION */}
      <section className="relative py-32 overflow-hidden">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 animate-fade-in" style={{ color: '#B8D4F1' }}>
              Affordable Learning
            </h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Premium education shouldn't be expensive. Join for just $1 and unlock everything.
            </p>
          </div>

          {/* Pricing Card */}
          <div className="max-w-2xl mx-auto">
            <div className="relative rounded-2xl border border-blue-400/20 overflow-hidden bg-card/50 backdrop-blur p-12">
              <GridOverlay opacity={0.05} />
              
              <div className="relative z-10 text-center">
                <h3 className="text-4xl font-bold mb-4" style={{ color: '#B8D4F1' }}>
                  Aura Nova Pro
                </h3>
                <div className="mb-8">
                  <span className="text-6xl font-bold text-blue-400">$1</span>
                  <span className="text-muted-foreground text-lg ml-2">first month</span>
                </div>
                
                <ul className="space-y-4 mb-8 text-left max-w-md mx-auto">
                  {[
                    'Unlimited access to all courses',
                    'Live coding challenges',
                    'Community support',
                    'Project portfolio builder',
                    'Expert code reviews',
                    'Mentorship opportunities',
                    'Career guidance',
                    'Job board access'
                  ].map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <Trophy className="w-5 h-5 text-blue-400 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className="w-full px-8 py-4 bg-blue-500 text-white rounded-lg font-bold text-lg hover:bg-blue-600 transition-all duration-300 hover:scale-105">
                  Start Learning for $1
                </button>
                
                <p className="text-muted-foreground text-sm mt-4">
                  Then $9.99/month. Cancel anytime.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SUCCESS STORIES */}
      <section className="relative py-32 bg-gradient-dark overflow-hidden">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-5xl lg:text-6xl font-bold mb-6 animate-fade-in" style={{ color: '#B8D4F1' }}>
              Success Stories
            </h2>
            <p className="text-muted-foreground text-xl max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Join thousands who've transformed their careers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: 'Sarah Chen', role: 'Junior Developer → Senior Engineer', story: 'Went from zero coding knowledge to landing a job at a top tech company in 6 months.' },
              { name: 'Marcus Johnson', role: 'Career Switcher', story: 'Transitioned from marketing to web development and built my first SaaS product.' },
              { name: 'Alex Rivera', role: 'Open Source Contributor', story: 'Started as a beginner, now maintaining popular open source projects.' },
            ].map((story, idx) => (
              <div
                key={idx}
                className="p-8 bg-card border border-border rounded-xl hover:border-blue-400/50 transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <div className="flex items-center gap-2 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-blue-400">★</span>
                  ))}
                </div>
                <h4 className="text-xl font-bold mb-2" style={{ color: '#B8D4F1' }}>{story.name}</h4>
                <p className="text-blue-300 text-sm font-semibold mb-3">{story.role}</p>
                <p className="text-muted-foreground">{story.story}</p>
              </div>
            ))}
          </div>
        </div>

        <GridOverlay opacity={0.05} />
      </section>

      {/* FINAL CTA */}
      <section className="relative py-32 overflow-hidden">
        <div className="container text-center">
          <h2 className="text-5xl lg:text-6xl font-bold mb-8 animate-fade-in" style={{ color: '#B8D4F1' }}>
            Ready to Start Your
            <br />
            Developer Journey?
          </h2>
          <p className="text-muted-foreground text-xl mb-12 max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
            Join thousands of developers learning, building, and growing together. Your first month is just $1.
          </p>
          <button className="px-12 py-6 bg-blue-500 text-white rounded-lg font-bold text-lg hover:bg-blue-600 transition-all duration-300 hover:scale-105 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            Join for $1 Today
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-border py-16 bg-gradient-dark">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Code2 className="w-6 h-6 text-blue-400" />
                <span className="font-bold text-blue-300 text-lg">AURA NOVA</span>
              </div>
              <p className="text-muted-foreground">Learn. Build. Create. Together.</p>
            </div>
            {['Courses', 'Community', 'Resources'].map((col, idx) => (
              <div key={idx}>
                <h4 className="font-bold mb-4 text-lg" style={{ color: '#B8D4F1' }}>{col}</h4>
                <ul className="space-y-2 text-muted-foreground">
                  <li><a href="#" className="hover:text-blue-300 transition">Link One</a></li>
                  <li><a href="#" className="hover:text-blue-300 transition">Link Two</a></li>
                  <li><a href="#" className="hover:text-blue-300 transition">Link Three</a></li>
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-muted-foreground">
            <p>&copy; 2026 Aura Nova. Learn. Build. Create.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-blue-300 transition">Privacy</a>
              <a href="#" className="hover:text-blue-300 transition">Terms</a>
              <a href="#" className="hover:text-blue-300 transition">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
